//
//  StatesTableViewController.h
//  US_State_info
//
//  Created by Dona varghese on 11/5/17.
//  Copyright © 2017 Dona varghese. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "States.h"
#import "StateTableViewCell.h"
#import "StateDetailViewController.h"
@interface StatesTableViewController : UITableViewController<UITableViewDelegate, UITableViewDataSource>

@end
