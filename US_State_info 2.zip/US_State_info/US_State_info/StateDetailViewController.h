
#import <UIKit/UIKit.h>
#import "States.h"
@interface StateDetailViewController : UIViewController
@property(strong, nonatomic)States* myState;
@end
