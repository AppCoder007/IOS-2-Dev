//
//  main.m
//  GetMyHeight
//
//  Created by Dona varghese on 10/27/17.
//  Copyright © 2017 Dona varghese. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
