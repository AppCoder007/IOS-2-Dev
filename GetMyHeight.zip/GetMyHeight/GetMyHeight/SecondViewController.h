//
//  SecondViewController.h
//  GetMyHeight
//
//  Created by Dona varghese on 10/27/17.
//  Copyright © 2017 Dona varghese. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SecondViewController : NSObject
@property(nonatomic,strong) NSString *name;
@property(nonatomic, strong) NSString *height;


@end
