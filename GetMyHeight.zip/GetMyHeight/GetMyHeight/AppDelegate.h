//
//  AppDelegate.h
//  GetMyHeight
//
//  Created by Dona varghese on 10/27/17.
//  Copyright © 2017 Dona varghese. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

