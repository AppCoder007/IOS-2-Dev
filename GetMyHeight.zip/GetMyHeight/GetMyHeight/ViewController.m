//
//  ViewController.m
//  GetMyHeight
//
//  Created by Dona varghese on 10/27/17.
//  Copyright © 2017 Dona varghese. All rights reserved.
//

#import "ViewController.h"
#import "SecondViewController.h"
@interface ViewController ()



@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]
                                   initWithTarget:self action:@selector(dismissKeyboard)];
    
    [self.view addGestureRecognizer:tap];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)buttonPress:(id)sender {
    NSString *name1 ;
    NSString *heightFeet;
    NSString *HeightInches;
    NSString *totalHeight;
    name1 = _getName.text;
    heightFeet = _getHeightFeet.text;
    HeightInches = _getHeightInches.text;
    NSInteger feet = [heightFeet integerValue];
    NSInteger inches =[HeightInches integerValue];
    float total = feet*12*.0254 + inches*.0254;
    totalHeight = [NSString stringWithFormat:@"%.2f", total];
    NSString *displayText =  [NSString stringWithFormat:@"Hello, %@ \nyour height of %d''  %d' is %@ meters " ,name1, feet, inches, totalHeight ]  ;
    _label.text = displayText;
}


-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    NSString *name1 ;
    NSString *heightFeet;
    NSString *HeightInches;
    NSString *totalHeight;
    name1 = _getName.text;
    heightFeet = _getHeightFeet.text;
    HeightInches = _getHeightInches.text;
    NSInteger feet = [heightFeet integerValue];
    NSInteger inches =[HeightInches integerValue];
    float total = feet*12*.0254 + inches*.0254;
    totalHeight = [NSString stringWithFormat:@"%.2f", total];
    NSString *displayText =  [NSString stringWithFormat:@"Hello, %@ \nyour height of %d''  %d' is %@ meters " ,name1, feet, inches, totalHeight ]  ;
    _label.text = displayText;
    
    SecondViewController *nameDestination = [segue destinationViewController];
 
    
}

- (void) dismissKeyboard {
    [_getName resignFirstResponder];
    [_getHeightInches resignFirstResponder];
    [_getHeightFeet resignFirstResponder];
}


@end
