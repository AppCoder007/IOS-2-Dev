//
//  ViewController.h
//  GetMyHeight
//
//  Created by Dona varghese on 10/27/17.
//  Copyright © 2017 Dona varghese. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *getName;
@property (weak, nonatomic) IBOutlet UITextField *getHeightFeet;

@property (weak, nonatomic) IBOutlet UITextField *getHeightInches;
@property (weak, nonatomic) IBOutlet UILabel *label;

@end

